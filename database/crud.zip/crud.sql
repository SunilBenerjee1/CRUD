CREATE TABLE IF NOT EXISTS `students_details` (
  `student_id` int(11) NOT NULL AUTO_INCREMENT,
  `enrolment_number` int(10) NOT NULL UNIQUE KEY,
  `student_name` varchar(50) DEFAULT NULL,
  `student_course` int(11) DEFAULT NULL,
  `student_email` varchar(50) DEFAULT NULL,
  `student_address` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`student_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `login_details` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) NOT NULL UNIQUE KEY,
  `user_email` varchar(50) DEFAULT NULL,
  `user_password` varchar(100) DEFAULT NULL,
  `user_role` int(11) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;


CREATE TABLE IF NOT EXISTS `course_details` (
  `course_id` int(11) NOT NULL AUTO_INCREMENT,
  `course_title` varchar(50) NOT NULL UNIQUE KEY,
  `course_description` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`course_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1;


INSERT INTO students_details (`enrolment_number`, `student_name`, `student_course`, `student_email`, `student_address`)
values 
('101', 'Salman Khan', 1, 'salman@email.com', 'Delhi'),
('102', 'Akshay Kumar', 2, 'akshay@email.com', 'Delhi'),
('103', 'Shahid Kapoor', 4, 'shahid@email.com', 'Mumbai'),
('104', 'Juhi Chawla', 5, 'juhi@email.com', 'Haryana'),
('105', 'Karan Singh', 3, 'karan@email.com', 'Mumbai'),
('106', 'Salim Khan', 6, 'salim@email.com', 'Haryana');

INSERT INTO login_details (`user_name`, `user_email`, `user_password`, `user_role`)
values
('Admin', 'admin@email.com', '7b902e6ff1db9f560443f2048974fd7d386975b0', 1);

INSERT INTO course_details (`course_title`, `course_description`)
values 
('BA', 'Bachelor of Arts'),
('BCOM', 'Bachelor of Commerce'),
('BSC', 'Bachelor of Science'),
('BCA', 'Bachelor of Computer Application'),
('BAG', 'Bachelor of Arts General'),
('BBA', 'Bacheor of Business Administration');